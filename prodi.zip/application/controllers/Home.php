<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct(){
		parent::__construct();
	
		if($this->session->userdata('status') != "login"){
			redirect(site_url("login"));
		} 
	}
	public function index()
	{
		$usan = $this->session->userdata('nama');
		$kue = $this->M_login->hak_ak($usan); 
		$query = $this->M_dokumen->get_dokumen(); 
		$tampil_kategori = $this->M_dokumen->tampil_kategori(); 

		$ttal_std = $this->M_dokumen->hitung_std(); 
		//$ttal_std1 = $this->M_dokumen->hitung_std1(); 
		
		foreach($ttal_std as $row){ 
			if ($row->standar != 1) { $std1[] = 0; }elseif ($row->standar == 1) { $std1[] = $row->jumlah_dok; }
			if ($row->standar != 2) { $std2[] = 0; }elseif ($row->standar == 2) { $std2[] = $row->jumlah_dok; }
			if ($row->standar != 3) { $std3[] = 0; }elseif ($row->standar == 3) { $std3[] = $row->jumlah_dok; }
			if ($row->standar != 4) { $std4[] = 0; }elseif ($row->standar == 4) { $std4[] = $row->jumlah_dok; }
			if ($row->standar != 5) { $std5[] = 0; }elseif ($row->standar == 5) { $std5[] = $row->jumlah_dok; }
			if ($row->standar != 6) { $std6[] = 0; }elseif ($row->standar == 6) { $std6[] = $row->jumlah_dok; }
			if ($row->standar != 7) { $std7[] = 0; }elseif ($row->standar == 7) { $std7[] = $row->jumlah_dok; }
			if ($row->standar != 8) { $std8[] = 0; }elseif ($row->standar == 8) { $std8[] = $row->jumlah_dok; }
			if ($row->standar != 9) { $std9[] = 0; }elseif ($row->standar == 9) { $std9[] = $row->jumlah_dok; }
		}


		$dataHalaman = array(   
		  'pagea'	=> "beranda",
          'da' => $kue,
          'query'   => $query,
          'tampil_kategori'=>$tampil_kategori,
          'std1'=>$std1,
          'std2'=>$std2,
          'std3'=>$std3,
          'std4'=>$std4,
          'std5'=>$std5,
          'std6'=>$std6,
          'std7'=>$std7,
          'std8'=>$std8,
          'std9'=>$std9,
        );
 
		$this->load->view('dashboard/v_header',$dataHalaman);
		$this->load->view('dashboard/v_home');
		$this->load->view('dashboard/v_footer2');
	}
}
